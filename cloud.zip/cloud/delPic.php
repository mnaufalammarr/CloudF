<?php
  include './conn.php';
  $id = $_GET["id"];
  $query = "SELECT count(*) AS total , url_pic FROM tb_pic WHERE id_pic='$id'";
  $result = mysqli_query($conn,$query);
  while($row = mysqli_fetch_assoc($result))
  { $total = $row['total'];
    $url = $row['url_pic'];
    $img = "./storage/img/".$url;}

  if(!$result){
    die ("Query Error: ".mysqli_errno($conn).
       " - ".mysqli_error($conn));
  }else if($total != 0){
    if($url != ''){
      if(!unlink($img)){
        echo "<script>alert('Data gagal dihapus.');window.location='picture.php';</script>";}
        else{
          $query = "DELETE FROM tb_pic WHERE id_pic='$id'";
          $result = mysqli_query($conn,$query);
          if(!$result){
            die ("Query Error: ".mysqli_errno($conn).
               " - ".mysqli_error($conn));
          }else{
            echo "<script>alert('Data berhasil dihapus.');window.location='picture.php';</script>";
          }
        }
  }else{

     $query = "DELETE FROM tb_pic WHERE id_pic='$id' ";
      $hasil_query = mysqli_query($conn, $query);

      if(!$hasil_query) {
        die ("Gagal menghapus data: ".mysqli_errno($conn).
        " - ".mysqli_error($conn));
      } else {
        echo "<script>alert('Data berhasil dihapus.');window.location='picture.php';</script>";
      }
  }
  }else{
    $query = "DELETE FROM tb_pic WHERE id_pic='$id' ";
    $hasil_query = mysqli_query($conn, $query);

    if(!$hasil_query) {
      die ("Gagal menghapus data: ".mysqli_errno($conn).
      " - ".mysqli_error($conn));
    } else {
      echo "<script>alert('Data berhasil dihapus.');window.location='picture.php';</script>";
    }
  }