-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 04, 2022 at 10:20 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_cloud`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_adm` int(11) NOT NULL,
  `nama_adm` varchar(30) NOT NULL,
  `no_adm` varchar(15) NOT NULL,
  `mail_adm` varchar(50) NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_admin`
--

INSERT INTO `tb_admin` (`id_adm`, `nama_adm`, `no_adm`, `mail_adm`, `username`, `password`) VALUES
(4, 'ammar', 'ammar', 'ammar@gmail.com', 'Ammar', 'Ammar'),
(5, 'M Naufal Ammar R', '087852888998', 'mnaufalammarr.15@gmail.com', 'daffa', 'daffa');

-- --------------------------------------------------------

--
-- Table structure for table `tb_file`
--

CREATE TABLE `tb_file` (
  `id_file` int(11) NOT NULL,
  `id_adm` int(11) NOT NULL,
  `nama_file` varchar(25) NOT NULL,
  `tanggal_file` varchar(20) NOT NULL,
  `url_file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_file`
--

INSERT INTO `tb_file` (`id_file`, `id_adm`, `nama_file`, `tanggal_file`, `url_file`) VALUES
(4, 4, 'Proposal', '08-07-2022', '531-PROPOSAL JUDUL ARTIKEL ILMIAH FIX.pdf');

-- --------------------------------------------------------

--
-- Table structure for table `tb_note`
--

CREATE TABLE `tb_note` (
  `id_note` int(11) NOT NULL,
  `id_adm` int(11) NOT NULL,
  `nama_note` varchar(25) NOT NULL,
  `tanggal_note` varchar(20) NOT NULL,
  `des_note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_note`
--

INSERT INTO `tb_note` (`id_note`, `id_adm`, `nama_note`, `tanggal_note`, `des_note`) VALUES
(4, 4, 'Jadwal Semhas', '08-07-2022', 'Selasa, 12 Juli 2022 ');

-- --------------------------------------------------------

--
-- Table structure for table `tb_pic`
--

CREATE TABLE `tb_pic` (
  `id_pic` int(11) NOT NULL,
  `id_adm` int(11) NOT NULL,
  `nama_pic` varchar(25) NOT NULL,
  `tanggal_pic` varchar(20) NOT NULL,
  `url_pic` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_pic`
--

INSERT INTO `tb_pic` (`id_pic`, `id_adm`, `nama_pic`, `tanggal_pic`, `url_pic`) VALUES
(31, 4, 'LoginPage', '08-07-2022', '219-LoginPage.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `tb_vid`
--

CREATE TABLE `tb_vid` (
  `id_vid` int(11) NOT NULL,
  `id_adm` int(11) NOT NULL,
  `nama_vid` varchar(25) NOT NULL,
  `tanggal_vid` varchar(20) NOT NULL,
  `url_vid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_vid`
--

INSERT INTO `tb_vid` (`id_vid`, `id_adm`, `nama_vid`, `tanggal_vid`, `url_vid`) VALUES
(5, 4, 'Tutor Login', '08-07-2022', '934-login.mp4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_adm`);

--
-- Indexes for table `tb_file`
--
ALTER TABLE `tb_file`
  ADD PRIMARY KEY (`id_file`);

--
-- Indexes for table `tb_note`
--
ALTER TABLE `tb_note`
  ADD PRIMARY KEY (`id_note`);

--
-- Indexes for table `tb_pic`
--
ALTER TABLE `tb_pic`
  ADD PRIMARY KEY (`id_pic`);

--
-- Indexes for table `tb_vid`
--
ALTER TABLE `tb_vid`
  ADD PRIMARY KEY (`id_vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_adm` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tb_file`
--
ALTER TABLE `tb_file`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_note`
--
ALTER TABLE `tb_note`
  MODIFY `id_note` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tb_pic`
--
ALTER TABLE `tb_pic`
  MODIFY `id_pic` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `tb_vid`
--
ALTER TABLE `tb_vid`
  MODIFY `id_vid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
