<?php 
session_start();
$conn = new mysqli("localhost", "root", "", "db_cloud") or die("Koneksi Error");
?>